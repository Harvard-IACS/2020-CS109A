Title: S-Section 03: Multiple Linear and Polynomial Regression 
Category: sections
Slug: section3
Author: Marios Mattheakis, Sean Murphy, Yinyu Ji
Date: 2020-09-25
Tags: multiple linear regression, polynomial regression, categorical variables, interaction terms, model selection, pairplot, bootstrap

## Jupyter Notebooks

- [S-Section 3: Multiple Linear  and Polynomial Regression](notebook/cs109a_section_3.ipynb)
